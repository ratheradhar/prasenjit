package com.genuine_meaning.genuinemeaningpro;

public class Config {
    public static String url="https://genuine-meaning-e9160.firebaseio.com/";
}

